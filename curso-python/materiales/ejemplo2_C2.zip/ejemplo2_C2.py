#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# ejemplo2_c2.py


# In[ ]:


"""Determina el valor máximo de cuatro números"""


# In[ ]:


no1=float(input('Ingresa el primer número: '))


# In[ ]:


no2=float(input('Ingresa el segundo número: '))


# In[ ]:


no3=float(input('Ingresa el tercer número: '))


# In[ ]:


no4=float(input('Ingresa el cuarto número: '))


# In[ ]:


maximo=no1
if no2>maximo:
    maximo=no2

if no3>maximo:  
    maximo=n3 

if no4>maximo: 
    maximo=n4


# In[ ]:


print('El valor máximo es', maximo)


# In[ ]:




